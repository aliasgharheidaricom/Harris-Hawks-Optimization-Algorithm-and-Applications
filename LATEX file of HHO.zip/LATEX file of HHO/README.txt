Just upload the files of this folder to a new project in https://www.overleaf.com/ to see the HHO section. 
